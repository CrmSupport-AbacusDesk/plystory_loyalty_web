import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-details',
  templateUrl: './coupon-details.component.html',
})
export class CouponDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
